-- Assign each statistical area with a police station
CREATE TABLE statistical_areas_with_station AS
SELECT DISTINCT ON (sa.area_id) sa., ps.
FROM statistical_areas sa
LEFT JOIN police_stations ps ON ST_Within(sa.geometry, ps.geometry)
ORDER BY sa.area_id, ST_Area(ST_Intersection(sa.geometry, ps.geometry)) DESC;

-- Export statistical areas with assigned police stations as GeoJSON
COPY (SELECT * FROM statistical_areas_with_station) TO 'path_to_output_geojson.geojson' (FORMAT 'GeoJSON');