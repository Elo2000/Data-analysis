-- Summarize crime count per StatisticCrimeGroup for each statistical area and year
CREATE TABLE crime_group_counts AS
SELECT area_id, year, "StatisticCrimeGroup", COUNT(*) AS crime_count
FROM statistical_areas sa
LEFT JOIN crime_data cd ON sa.area_id = cd.area_id
GROUP BY area_id, year, "StatisticCrimeGroup";

-- Find the most popular crime group for each statistical area and year
CREATE TEMPORARY TABLE most_popular_crime_group AS
SELECT area_id, year, MAX(crime_count) AS max_crime_count
FROM crime_group_counts
GROUP BY area_id, year;

-- Create a new attribute indicating the most popular crime group for each statistical area
ALTER TABLE statistical_areas ADD COLUMN most_popular_crime_group TEXT;
UPDATE statistical_areas sa
SET most_popular_crime_group = c."StatisticCrimeGroup"
FROM most_popular_crime_group m
JOIN crime_group_counts c ON sa.area_id = c.area_id AND sa.year = c.year
WHERE m.area_id = sa.area_id AND m.year = sa.year AND m.max_crime_count = c.crime_count;

-- Export statistical areas map as GeoJSON
COPY (SELECT * FROM statistical_areas) TO 'path_to_output_geojson.geojson' (FORMAT 'GeoJSON');