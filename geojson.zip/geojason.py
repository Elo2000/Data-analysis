import geopandas as gpd
import pandas as pd

# Read the statistical area shapefile and crime data CSV
statistical_areas = gpd.read_file('statisticalareas_2020_demography.gdb')
crime_data = pd.read_excel('Jerusalem-Telaviv.xlsx')

# Merge statistical areas with crime data based on a common attribute
merged_data = statistical_areas.merge(crime_data, left_on='StatArea', right_on='StatArea')

# Group by statistical area and crime group, and calculate the crime count
grouped_data = merged_data.groupby(['StatArea', 'StatisticCrimeGroup']).size().reset_index(name='crime_count')

# Find the most popular crime group for each statistical area
most_popular_group = grouped_data.groupby('StatArea')['crime_count'].idxmax()
popular_crime_groups = grouped_data.loc[most_popular_group]

# Export areas map as GeoJSON
popular_crime_groups.to_file('popular_crime_groups.geojson', driver='GeoJSON')
