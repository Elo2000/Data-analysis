import math
import geojson

TILE_SIZE = 256

def get_tile_limit(x, y, zoom):
    num_tile = 2.0 ** zoom
    long_1 = x / num_tile * 360.0 - 180.0
    latid_1 = math.atan(math.sinh(math.pi * (1 - 2 * y / num_tile)))
    latid_1= math.degrees(latid_1)
    long_2 = (x + 1) / num_tile * 360.0 - 180.0
    latid_2 = math.atan(math.sinh(math.pi * (1 - 2 * (y + 1) / num_tile)))
    latid_2 = math.degrees(latid_2)
    return [long_1, latid_1, long_2, latid_2]

def create_polygons(zoom):
    features = []
    for x in range(2 ** zoom):
        for y in range(2 ** zoom):
            lim = get_tile_limit(x, y, zoom)
            polygon = geojson.Polygon([[(lim[0], lim[1]),
                                         (lim[0], lim[3]),
                                         (lim[2], lim[3]),
                                         (lim[2], lim[1]),
                                         (lim[0], lim[1])]])
            feature = geojson.Feature(geometry=polygon, properties={"zoom": zoom, "x": x, "y": y})
            features.append(feature)
    f_collect = geojson.FeatureCollection(features)
    return f_collect

# Create GeoJSON files
zoom_level = [5, 10]
for zoom in zoom_level:
    f_collect = create_polygons(zoom)
    with open('/Users/Helen/geojson_files/file.geojson', "w") as f:
        geojson.dump(f_collect, f)